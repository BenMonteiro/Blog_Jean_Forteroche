<?php
/**
 * Custom exception class for login errors
 * This class extends Exception class
 */

class LoginException extends Exception
{

}
