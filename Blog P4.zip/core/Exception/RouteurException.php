<?php
/**
 * Custom exception class for routing errors
 * This class extends Exception class
 */

class RouteurException extends Exception
{

}
