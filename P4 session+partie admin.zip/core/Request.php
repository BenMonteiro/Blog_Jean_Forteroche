<?php
/**
 * This class take the URL infos and assign it to variables
 */
session_start();

class Request 
{
    protected $path;
    protected $urlComponent;
    protected $controllerName;
    protected $actionName;

    private static $request = null;

    /**
     * Construct analyse the URL path and decomposed it to get Url components.
     * The first element [0] of the URL is the controller name 
     * The second element [1] is the action name 
     */
    public function __construct()
    {
        $this->getPath();
        $this->getUrlComponents();
        $this->controllerName = $this->urlComponent[0];
        $this->actionName = $this->urlComponent[1];
    }

    /**
     * Request class is handled by singleton pattern. 
     * In this way, if a Request object already exist, the application use the same instance instead of create a new 
     */
    public static function getRequest()
    {
        if (null === static::$request) {

            static::$request = new Request();
        }

        return static::$request;
    }

    /**
     * @return string       [return the URL path]
     */
    public function getPath(): string
    {
        $uri = $_SERVER["REQUEST_URI"];
        $path = (parse_url($uri, PHP_URL_PATH));
        $path = trim($path, "/");

        return $this->path = $path;
    }

    /**
     * @return array        [return an array of the URL elements] 
     */
    public function getUrlComponents(): array
    {
        return $this->urlComponent = explode('/', $this->path);
    }

    /**
     * @return string       [return the name of the controller to call]
     */
    public function getControllerName(): string
    {
        return $this->controllerName;
    }

    /**
     * @return string       [return the name of the action to call]
     */
    public function getActionName(): string
    {
        return $this->actionName;
    }

    /**
     * @param string $key      [The key of the postData we want to return]
     * @return string       [return ]
     */
    public function getPostParams(string $key): string
    {
        if (isset($key)) {

        return htmlspecialchars($_POST[$key]);
        }
    }

    public function getAdminLogin()
    {
        $_SESSION['login'] = $this->getPostParams('login');
        return $_SESSION['login'];
    }

}