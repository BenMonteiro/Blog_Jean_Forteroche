<?php
/**
 * Custom exception class for Routeur generated errors
 * This class extends Exception class
 */

class RouteurException extends Exception
{

}