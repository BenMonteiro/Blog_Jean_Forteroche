<?php

require_once ROOT_PATH.'/core/DefaultController.php';
 
/**
* Controll the page to display 
*/
class FrontController extends DefaultController
{

    public function home()
    {
        $this->renderView('Frontend/Pages/accueil.twig', []);
    }

    public function chapter1()
    {
        $this->renderView('Frontend/Pages/chapitre1.twig', []);
    }

    public function chapter2()
    {
        $this->renderView('Frontend/Pages/chapitre2.twig', []);
    }

    public function author()
    {
        $this->renderView('Frontend/Pages/author.twig', []);
    }

    public function contact()
    {
        $this->renderView('Frontend/Pages/contact.twig', []);
    }

    public function error404()
    {
        $this->renderView('Frontend/Pages/error404.html', []);
    }

    /**
     * Require the ContactFormManager class and the send method with $datas for parameters. 
     * $datas are the informations obtained via the contact form.
     * Then load the contactSuccess page
     */
    public function contactSuccess()
    {
        $datas = [
            'subject' => $this->request->getPostParams('subject'),
            'message' => $this->request->getPostParams('message'),
            'headers' => [
                'FROM' => $this->request->getPostParams('firstname'). ' ' . $this->request->getPostParams('name'), 
                'Reply-To' => $this->request->getPostParams('email')]
            ];

        require_once ROOT_PATH.'/src/Models/ContactFormHandler.php';
        $contactForm = new ContactFormHandler();
        $contactForm->send($datas);

        $this->renderView('Frontend/Pages/contactSuccess.twig',[]);
    }
}




