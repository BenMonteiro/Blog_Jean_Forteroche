<?php

require_once ROOT_PATH.'/core/DefaultController.php';

class AdminFrontController extends DefaultController
{

    protected $login;

    public function log()
    {
        session_destroy();
        $this->renderView('Backend/Pages/log.twig', []);
    }

    public function logRedirection()
    {
        require_once ROOT_PATH.'/src/Models/LoginFormHandler.php';
        $redirection = new LoginFormHandler();
        $redirection->redirect();
    }

    public function errorLog()
    {
        $this->renderView('Backend/Pages/log.twig', ['error' => 'L\'identifiant et/ou le mot de passe sont incorrect !']);
    }

    public function home()
    {
        if (isset($_SESSION['login'])) {

        $this->login = $_SESSION['login'];

        $this->renderView('Backend/Pages/home.twig', ['login' => $this->login,
                                                    'comments' => 556]);
        } else {

            $this->renderView('Backend/Pages/log.twig', []);
        }
    }

    public function add()
    {
        if (isset($_SESSION['login'])) {

        $this->renderView('Backend/Pages/add.twig', []);

        } else {

            $this->renderView('Backend/Pages/log.twig', []);
        }
    }

    public function manage()
    {
        if (isset($_SESSION['login'])) {

        $this->renderView('Backend/Pages/manage.twig', []);

        } else {

            $this->renderView('Backend/Pages/log.twig', []);
        }
    }


    public function comments()
    {
        if (isset($_SESSION['login'])) {

        $this->renderView('Backend/Pages/comments.twig', []);

        } else {

            $this->renderView('Backend/Pages/log.twig', []);
        }
    }
}