<?php

class News
{
    protected $PDOConnection;
    protected $reqestData;

    public function __construct()
    {
        require_once ROOT_PATH.'/src/Models/PDOConnection.php';
        $this->PDOConnection = PDOConnection::getMySqlConnection();
    }
    
    public function requestNews()
    {
        $this->reqestData = $this->PDOConnection->query('SELECT * FROM articles ORDER BY publicationDate DESC');
    }
}