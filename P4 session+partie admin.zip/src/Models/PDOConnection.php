<?php

/**
 * Connection to the database
 * we use a singleton pattern in to order to only have one object of the PDOConnection
 */
class PDOConnection
{
    private static $dbConnection = null;

    public static function getMySqlConnection()
    {
        try {
            if (null === static::$dbConnection){
                static::$dbConnection = new PDO('mysql:host=localhost;dbname=blog_p4', 'root', '');
            }

            return static::$dbConnection;
        } 
        catch (PDOException $e) {

            die('Erreur : ' . $e->getMessage());
        }
    }
}