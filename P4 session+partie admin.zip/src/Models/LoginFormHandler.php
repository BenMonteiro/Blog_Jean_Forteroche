<?php

class LoginFormHandler
{
    protected $defaultParams = [];
    protected $request;
    protected $login;

    public function __construct()
    {
        require_once ROOT_PATH.'/core/Request.php';
        $this->request = Request::getRequest();
    }
 
    public function get($param)
    {

        $xml = new \DOMDocument;
        $xml->load(ROOT_PATH.'/core/Config/config.xml');

        $elements = $xml->getElementsByTagName('define');

        foreach ($elements as $element)
        {
          $this->defaultParams[$element->getAttribute('var')] = $element->getAttribute('value');
        }

        if (isset($this->defaultParams[$param]))
        {
            return $this->defaultParams[$param];
        }
    }

    public function redirect()
    {
        if($this->request->getPostParams('login') === $this->get('login') && $this->request->getPostParams('password') === $this->get('password')){

            $this->login = $this->request->getAdminLogin();
            
            header("Location: /AdminFrontController/home");

        } else {

            header("Location: /AdminFrontController/errorLog");
        }
    }
}