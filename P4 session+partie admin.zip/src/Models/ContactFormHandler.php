<?php

/**
 * Manage the way to get the informations send via the contact form
 */
class ContactFormHandler
{

    /**
     * Send an email to the admin with the message send by the user
     * 
     * @param array $datas      [datas to implement in the email]
     * @return void
     */
    public function send(array $datas = []): void
    {
        mail(
            'benjamin.monteirodasilva@gmail.com', 
            $datas['subject'], 
            $datas['message'], 
            $datas['headers'] = []
        );
    }
}